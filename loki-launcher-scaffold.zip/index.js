export default function Home() {
  return (
    <main style={{fontFamily:'system-ui', padding:24}}>
      <h1>Loki Launcher</h1>
      <p>Minimal UI shell. Hook up APIs later.</p>
    </main>
  );
}